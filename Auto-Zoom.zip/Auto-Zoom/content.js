
console.log("EXTENSION");
console.log(document.readyState);

recurs();

function recurs(){
    if(document.readyState == "complete"){
        for(var i = 0; i != 15; i++){
            document.getElementById("editor-increment-font").click();
        }
        console.log("inside");
    } else {
        setTimeout(recurs, 1000);
        console.log("tryin again");
    }
}